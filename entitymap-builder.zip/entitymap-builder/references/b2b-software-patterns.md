# B2B Software Entity-Modeling Patterns

How to model a complex B2B software site into EntityMap entities, types, and relations. Read after `spec-v1.0.md`.

## The strategic frame

For B2B software, the failure mode is conflation. AI blends the product with its nearest generic equivalent and erases differentiation. The lever EntityMap gives you is the ability to declare the publisher's own definitions into the retrieval layer. Three modeling moves carry most of the value:

1. Type coined terms as `ProprietaryTerm`, not `Concept`. A `ProprietaryTerm` description is treated as authoritative; a `Concept` gets blended with general priors. Mistyping a coined methodology as `Concept` invites the exact conflation EntityMap exists to prevent.
2. Use `canonicalLabel` to anchor proprietary terms to their generic category without surrendering the proprietary name. `name` carries the brand term; `canonicalLabel` carries the category. This lets AI resolve the surface form to the right category while keeping the publisher's label as the node.
3. Declare typed relations so the reasoning chain is read, not inferred. Feature hierarchies, metric-to-outcome links, and category positioning become explicit predicates rather than buried prose.

## Asset-to-type mapping

| Site asset | @type | Notes |
|---|---|---|
| The product | `SoftwareProduct` | Default for a SaaS app, API, or tool. |
| The product, if ecosystem or developer layer is central | `Platform` | Multi-sided or integration-heavy products. |
| A human-delivered offering | `Service` | Consulting, managed service, onboarding-as-service. Not software. |
| The company | `Organization` | Source of OFFERS. |
| A named, branded feature | `ProprietaryTerm` | When the feature name is coined and the definition is the publisher's. Most named SaaS features. |
| A generic feature with no coined name | `Concept` | Rare; usually fold into the product rather than as its own entity. |
| A coined methodology or framework | `Methodology` or `ProprietaryTerm` | `Methodology` for a named process or system; `ProprietaryTerm` for a coined concept or metric name. |
| A metric the product computes | `Metric` | Source of MEASURES. Give it a defined calculation in the description. |
| A category term the company is defining | `ProprietaryTerm` | When the company is coining or materially defining the category. |
| An established industry concept | `Concept` | Add `sameAs` by hand later. |
| Founders, named experts | `Person` | Source of AFFILIATED_WITH. |
| A learning hub, academy, docs portal | `Service` or `Guide` | `Service` if it is a product surface; `Guide` only for a substantial standalone instructional resource (flag for review). |
| A compliance regime the product is governed by | `Regulation` | Target of REGULATED_BY. |
| An integration standard or protocol | `Standard` | Versioned spec with a governance body. |
| Target audience or ICP segment | `ProprietaryTerm` | Model as a single entity describing the user groups; target it with TARGETS from the product. |

## The Concept vs ProprietaryTerm decision

This is the highest-leverage type decision for B2B software. Ask: does this concept exist independently of the brand?

- Exists independently (RAG, share of voice, churn, technical SEO): `Concept`. Add `sameAs` later. Consumers blend it with general knowledge.
- Coined or materially redefined by the publisher (a named metric, a branded methodology, a category the company is establishing): `ProprietaryTerm`. No `sameAs`. The publisher's definition is authoritative.

When a coined term has a generic parent, type it `ProprietaryTerm` and set `canonicalLabel` to the generic parent. Example from the reference file: `name: "AI Share of Voice"`, `canonicalLabel: "share of voice"`. This is the anti-conflation move.

## Feature hierarchy modeling

B2B software has dense feature trees that are easy to conflate. Model them with explicit structural relations:

- Company to product: `Organization OFFERS SoftwareProduct`. This company-to-product form is the canonical, safest OFFERS usage. The live standard also permits Platform, Service, or SoftwareProduct as the source, so a product offering its own sub-features validates too, but PART_OF is cleaner for sub-features. Pick OFFERS or PRODUCED_BY, never both on the same pair. The publisher's own EntityMap typically uses OFFERS.
- Product to feature: `Product OFFERS Feature` (if features are commercially distinct offerings and the product is modeled as a Platform/Service/SoftwareProduct that the Organization offers) OR `Feature PART_OF Product`. PART_OF is the safer, more common choice for sub-features. Use it consistently and never declare both PART_OF and INCLUDES on the same pair.
- Feature to capability it unlocks: `Feature ENABLES Capability` when the enablement is structural and unambiguous. Use IMPROVES (Tier 3, confidence required) only when the page actively claims a causal quality effect.
- Feature dependency: `Feature DEPENDS_ON OtherFeature` when one needs another to function. `REQUIRES` only when it is non-functional without it.

In the reference example, every feature (Brand Visibility Tracking, Topic Reports, Fact Tracker, GEO Action Plans) is a `ProprietaryTerm` with `PART_OF` pointing to the product, and the product carries `OFFERS` relations pointing back to each feature. Both directions exist because OFFERS and PART_OF are different predicates, not an inverse pair. Do not mix this up with the PART_OF/INCLUDES inverse-pair rule.

## Metric modeling

A metric the product computes is a `Metric` entity and the only valid source of MEASURES. Pattern:

- `Metric MEASURES Outcome` where Outcome is the concept the metric quantifies.
- `Metric PART_OF Feature` when the metric is surfaced inside a feature.
- Give the metric a defined calculation in its description (range, inputs, method). A metric without a calculation reads as marketing, not measurement.

Example: an AI Knowledge Score (0 to 100) MEASURES AI Brand Representation and is PART_OF the Topic Reports feature.

## Category positioning

When the company is defining an emerging category, model the category as a `ProprietaryTerm` (the company's framing is authoritative) and connect it:

- `Category DESCRIBED_BY Product` when the product page defines the category.
- `Category LEADS_TO Outcome` (Tier 3, confidence and context) when the page claims the category produces a result.
- Relate adjacent established concepts with `RELATES_TO` sparingly, or with `CONFLICTS_WITH` when the company positions against an old approach.

## People and organization

- `Person AFFILIATED_WITH Organization`. Source must be Person.
- `Person AUTHORED_BY` is wrong; authorship points from a work to a person. Use `Work AUTHORED_BY Person` if you model content works, otherwise use `DESCRIBED_BY` from a concept to the page a person wrote.
- Founders and named experts strengthen the entity graph and the E-E-A-T surface. Include them when pages carry real bios.

## Relation patterns common in B2B software

| Pattern | Predicate | Tier |
|---|---|---|
| Company offers product | OFFERS | 2 |
| Feature belongs to product | PART_OF | 1 |
| Metric quantifies outcome | MEASURES | 1 |
| Feature unlocks capability (structural) | ENABLES | 2 |
| Product designed for an ICP | TARGETS (confidence) | 3 |
| Product improves an outcome (claimed) | IMPROVES (confidence) | 3 |
| Methodology produces an outcome (claimed) | ACHIEVES (confidence) | 3 |
| Problem degrades an outcome | DEGRADES (confidence) | 3 |
| Product governed by a regulation | REGULATED_BY | 1 |
| Feature depends on another feature | DEPENDS_ON | 1 |
| Old approach conflicts with new | CONFLICTS_WITH | 2 |
| Person works at company | AFFILIATED_WITH | 1 |

## Entity count and depth

Aim for 12 to 25 entities for a focused B2B software product. Depth beats breadth: 15 well-evidenced entities outperform 80 with one weak chunk each. A typical product maps to roughly: 1 product, 1 organization, 4 to 8 features, 1 to 3 metrics, 1 to 4 coined methodologies or category terms, 2 to 4 established concepts, 1 to 3 people, plus audience and any regulation or standard.

## Common mistakes for B2B software

- Typing a coined methodology as `Concept`. This surrenders the authoritative definition. Use `ProprietaryTerm` or `Methodology`.
- Omitting `canonicalLabel` on proprietary terms with a generic parent. This is the surface-form resolution lever; without it the proprietary node floats disconnected from the category AI already knows.
- Inventing IMPROVES relations between features and outcomes the pages do not actually claim. Default to ENABLES (structural) or no relation. Reserve Tier 3 for claims the page actively makes.
- Modeling every micro-feature as its own entity. Fold minor features into the parent product's description. Promote a feature to an entity only when it has a coined name and real evidence.
- Marketing-language chunks. Pull definitions, statistics, and procedures, not hero-section taglines. The chunk must convey a complete fact when lifted out of context.
- Generic descriptions. "X is a SaaS platform" is not a definition. State what it does, for whom, and how it differs, in the publisher's own terms, extractive where possible.
