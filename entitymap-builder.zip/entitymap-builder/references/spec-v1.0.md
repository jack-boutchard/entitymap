# EntityMap v1.0 — Embedded Spec Reference

Authoritative for generation. Self-contained. Do not re-fetch the spec from the web. Source: entitymap.org/spec/v1.0 and the official reference prompt (github.com/entitymap). Version 1.0, status Stable, CC BY 4.0.

## Contents

1. What an EntityMap is
2. Conformance floor
3. Root object
4. Publisher object
5. Entity object
6. Core entity types
7. Chunk object
8. Relation object
9. The 24 standard predicates
10. Forbidden inverted predicate forms
11. The sameAs rule
12. Validation rules (errors and warnings)
13. Certification and verification status
14. The HTML companion file
15. Deploy and discovery
16. Sharding (large sites)

---

## 1. What an EntityMap is

A site publishes two files at the root of its domain, public, no authentication:

```
https://example.com/entitymap.json   (machine-readable, source of truth)
https://example.com/entitymap.html    (crawler- and human-readable, generated from the JSON)
```

Where `sitemap.xml` tells crawlers what pages exist, `entitymap.json` tells AI systems what a site knows: which entities it covers, how they relate, and where the evidence is. v1.0 is a publisher assertion standard with a small mandatory core (roughly 12 fields across three objects). Everything beyond the core is optional enrichment.

---

## 2. Conformance floor

A conforming file requires exactly three things: a valid root object, at least one entity, and at least one chunk per entity.

Two hard rules apply at all enrichment levels:
- `publisher` on every chunk MUST exactly match `publisher.name` in the root, including case and spacing.
- Tier 3 predicates (IMPROVES, DEGRADES, LEADS_TO, SUITED_FOR, TARGETS, ACHIEVES) MUST carry a `confidence` field.

| Object | Required fields |
|---|---|
| Root | `version`, `schema`, `publisher.name`, `publisher.url`, `generated`, `entities` |
| Entity | `entityId`, `@type`, `name`, `description`, `hasChunks` (min 1) |
| Chunk | `chunkId`, `text`, `sourceUrl`, `pageTitle`, `publisher` |
| Relation (if used) | `predicate`, `targetName`, plus `confidence` if Tier 3 |

---

## 3. Root object

```json
{
  "version": "1.0",
  "schema": "https://entitymap.org/spec/v1.0",
  "publisher": { "name": "...", "url": "..." },
  "generated": "2026-05-27T00:00:00Z",
  "verificationStatus": "generator-draft",
  "entities": [ ]
}
```

| Field | Conformance | Description |
|---|---|---|
| `version` | MUST | Must be "1.0". |
| `schema` | MUST | Must be "https://entitymap.org/spec/v1.0". |
| `publisher` | MUST | Publisher identity object. See §4. |
| `generated` | MUST | ISO 8601 timestamp. Update on every rebuild. A timestamp older than 30 days signals staleness. |
| `entities` | MUST | Array of entity objects, minimum 1. |
| `verificationStatus` | SHOULD | `"self-declared"`, `"generator-draft"`, or `"third-party-verified"`. LLM-assisted files not yet line-by-line reviewed MUST be `"generator-draft"`. |
| `profile` | MAY | Extension profile. Default `"core"`. |
| `previousVersion` | MAY | URI of prior file, enables consumer diffing. |
| `changeLog` | MAY | Array of change entries. `deprecated`/`merged` entries MUST include `replacedBy`. |
| `vocabulary` | MAY | Custom predicate declarations. Only if a needed predicate is outside the standard 24. |
| `shards` | MAY | Shard manifest for files over 200 entities. See §16. |

---

## 4. Publisher object

```json
{
  "name": "Canonical Brand Name",
  "url": "https://brand.com",
  "sameAs": "https://www.wikidata.org/wiki/Q..."
}
```

| Field | Conformance | Description |
|---|---|---|
| `name` | MUST | Canonical brand name. Never a domain, product name, or generic descriptor. Must match `publisher` on every chunk exactly. This is the name that appears in AI attribution. |
| `url` | MUST | Canonical publisher URL. |
| `sameAs` | MAY | Wikidata or Wikipedia URI anchoring the publisher to the open knowledge graph. |

---

## 5. Entity object

```json
{
  "entityId": "e_001",
  "@type": "Concept",
  "name": "Companion Planting",
  "description": "1-3 sentence definition as this publisher uses the concept.",
  "hasChunks": [ ],
  "relations": [ ],
  "alternateName": "Abbreviation",
  "canonicalLabel": "general label where name is proprietary",
  "maturityStatus": "proposed | established | deprecated",
  "audienceType": "technical | executive | general | regulatory",
  "status": "active | deprecated | merged",
  "replacedBy": "e_002"
}
```

| Field | Conformance | Description |
|---|---|---|
| `entityId` | MUST | Stable, unique. Simple prefix e_001, e_002. Never reuse a retired ID. |
| `@type` | MUST | A core type (§6) or a namespaced custom type (e.g. `acme:MetricComponent`). |
| `name` | MUST | The publisher's label, not a generic Wikipedia title. |
| `description` | MUST | 1 to 3 sentence definition as this publisher uses it. Specific to the publisher's context. |
| `hasChunks` | MUST | 1 to 5 evidence chunks. See §7. |
| `relations` | MAY | Typed relationships. See §8. Encouraged; even a sparse graph improves traversal. |
| `replacedBy` | MUST if deprecated/merged | entityId of the replacement. |
| `alternateName` | MAY | Abbreviation or surface-form variant. Aids disambiguation. |
| `canonicalLabel` | MAY | General concept label where the publisher uses a proprietary variant. Key differentiation lever for B2B software. |
| `maturityStatus` | MAY | proposed / established / deprecated. |
| `audienceType` | MAY | technical / executive / general / regulatory. |
| `status` | MAY | active / deprecated / merged. Default active. |
| `sameAs` | Do not add at generation time | See §11. |

---

## 6. Core entity types

The spec page (§4) describes 15 core types in three tiers. The official reference prompt adds a fourth tier with one type, `Guide`, for 16 total. Use the types below. Prefer the spec's 15 for safety; use `Guide` only for a substantial standalone instructional resource, and flag it for review since the type set is at the edge of the published spec.

**Tier 1, Knowledge**
- `Concept` — general domain term, common knowledge. Add `sameAs` by hand later. Consumers blend with general priors.
- `ProprietaryTerm` — publisher-coined concept. The definition here is authoritative. No `sameAs` expected.
- `Methodology` — named process, framework, or approach.
- `Metric` — measurable quantity with a defined calculation. The only valid source of MEASURES.
- `Taxonomy` — classification system the publisher maintains. Use COVERS for sub-categories.

**Tier 2, Actor**
- `Person` — named individual. The only valid source of AFFILIATED_WITH.
- `Organization` — company, institution, or body. The only valid source of OFFERS.
- `SoftwareProduct` — software application, SaaS tool, API, or developer platform.
- `PhysicalProduct` — tangible goods.
- `Service` — professional or subscription offering, not software.
- `Platform` — multi-sided or ecosystem-enabling product.
- `Place` — geographic location or venue.

**Tier 3, Temporal**
- `Event` — named occurrence with a defined time.
- `Standard` — specification or protocol with a version and governance body.
- `Regulation` — formal legal or regulatory instrument. Target of REGULATED_BY.

**Tier 4, Content (reference-prompt addition)**
- `Guide` — substantial instructional resource. Use sparingly; flag for review.

### Type decision rules

- Concept vs ProprietaryTerm: exists independently of the publisher, add `Concept`. Coined or materially defined by the publisher, use `ProprietaryTerm`.
- SoftwareProduct vs Platform vs Service: primarily software, `SoftwareProduct`. Ecosystem or developer layer central, `Platform`. Primarily human-delivered, `Service`.
- Standard vs Regulation: enacted into law, `Regulation`. Voluntary specification with a governance body, `Standard`.

NEVER use v0.x legacy types: `DefinedTerm`, `Product`, `ScholarlyArticle`, `CreativeWork`. The validator rejects them.

---

## 7. Chunk object

```json
{
  "chunkId": "c_001",
  "text": "Verbatim passage from the page.",
  "sourceUrl": "https://brand.com/page",
  "pageTitle": "Page Title",
  "publisher": "Canonical Brand Name",
  "retrieved": "2026-05-27T08:00:00Z",
  "relevanceScore": 0.92,
  "contentType": "definition | evidence | example | statistic | procedure",
  "audienceType": "technical | executive | general | regulatory"
}
```

| Field | Conformance | Description |
|---|---|---|
| `chunkId` | MUST | Unique within the file. |
| `text` | MUST | Extractive passage copied verbatim from the page. 1 to 5 sentences, max 600 characters. Do not paraphrase, summarise, or invent. If no suitable passage exists, omit the chunk. |
| `sourceUrl` | MUST | Canonical, publicly accessible URL of the source page. |
| `pageTitle` | MUST | Title of the source page at retrieval time. |
| `publisher` | MUST | Exactly matches `publisher.name`, including case and spacing. This is how attribution survives extraction into vector databases. |
| `retrieved` | SHOULD | ISO 8601 fetch timestamp. |
| `relevanceScore` | MAY | Float 0.0 to 1.0. |
| `contentType` | MAY | definition / evidence / example / statistic / procedure. |
| `audienceType` | MAY | technical / executive / general / regulatory. |

---

## 8. Relation object

```json
{
  "predicate": "IMPROVES",
  "targetId": "e_004",
  "targetName": "Retrieval Precision",
  "confidence": "declared",
  "context": {
    "condition": "when chunks carry publisher attribution",
    "temporal": "2024-onwards",
    "jurisdiction": null,
    "reviewedBy": "Editor Name",
    "reviewDate": "2026-04-01"
  },
  "targetUri": "https://...",
  "targetShard": "shards/part-002.json",
  "targetDescription": "One-sentence summary of target"
}
```

| Field | Conformance | Description |
|---|---|---|
| `predicate` | MUST | From the 24 standard predicates (§9) or a declared custom vocabulary. |
| `targetName` | MUST | Human-readable target name. Required in all cases; survives aggregation. |
| `confidence` | MUST for Tier 3 | `"declared"` or `"inferred"`. Required on Tier 3; optional on Tier 1/2. |
| `targetId` | SHOULD | entityId of an internal target. |
| `context` | MAY | Qualification object. Strongly recommended on LEADS_TO. |
| `targetUri` | MAY | URI for external targets (Wikidata, schema.org). |
| `targetShard` | MAY | Path to the shard file containing the target. |
| `targetDescription` | MAY | One-sentence target summary; present when `targetUri` is absent. |

A `confidence: "inferred"` relation without a `context` object produces a validator warning. Consuming systems discount inferred relations without qualification context.

---

## 9. The 24 standard predicates

All predicates uppercase. Inverses are implicit; never declare both directions of an inverse pair.

### Tier 1, Hard (11) — no confidence required, machine-trustable

| Predicate | Meaning | Constraint |
|---|---|---|
| INSTANCE_OF | subject is a specific example of object | target: Concept or Taxonomy |
| PART_OF | subject is a definitional constituent of object | inverse of INCLUDES |
| INCLUDES | subject contains object | inverse of PART_OF |
| DEPENDS_ON | subject needs object to function, partial function possible without it | weaker than REQUIRES |
| REQUIRES | subject cannot function at all without object | stronger than DEPENDS_ON |
| MEASURES | subject quantifies object | source MUST be Metric |
| PRODUCED_BY | subject is created or output by object | target: Person or Organization |
| REGULATED_BY | subject is governed by object | target: Regulation or Standard |
| AUTHORED_BY | subject is written by object | target: Person |
| AFFILIATED_WITH | subject is associated with object | source MUST be Person |
| COVERS | subject (hub) intentionally covers object (sub-topic) | source MUST be Concept, ProprietaryTerm, or Taxonomy |

### Tier 2, Structural (7) — confidence optional

| Predicate | Meaning | Constraint |
|---|---|---|
| RELATES_TO | general association | last resort; warns above 20% of all relations |
| PRECEDES | subject comes before object in a sequence | |
| ENABLES | subject makes object possible (structural) | inverse pair with PREVENTS |
| PREVENTS | subject blocks or reduces object | inverse pair with ENABLES |
| CONFLICTS_WITH | subject and object are incompatible | declare one direction only |
| DESCRIBED_BY | subject is documented by object | |
| OFFERS | subject makes object commercially available | source: Organization, Platform, Service, or SoftwareProduct; target is typically a product type (SoftwareProduct, Service, Platform, PhysicalProduct) but the live reference uses feature ProprietaryTerms too |

### Tier 3, Interpretive (6) — confidence REQUIRED

| Predicate | Meaning | Notes |
|---|---|---|
| IMPROVES | subject has a positive causal effect on object | inverse pair with DEGRADES |
| DEGRADES | subject has a negative causal effect on object | inverse pair with IMPROVES |
| LEADS_TO | subject contributes to object over time | context.condition strongly recommended |
| SUITED_FOR | subject happens to fit object well, not designed for it | |
| TARGETS | subject is intentionally designed for object | stronger than SUITED_FOR |
| ACHIEVES | subject successfully produces object as an outcome | |

### Predicate decision rules

- PART_OF vs DEPENDS_ON: definitional constituent, PART_OF. Separable concept that needs the other, DEPENDS_ON.
- INCLUDES vs COVERS: component-of, INCLUDES. Hub-topic to sub-topic, COVERS.
- ENABLES (Tier 2) vs IMPROVES (Tier 3): unambiguous structural enablement, ENABLES. Causal effect needing editorial judgement, IMPROVES (confidence required).
- TARGETS vs SUITED_FOR: designed for it, TARGETS. Happens to fit, SUITED_FOR.
- OFFERS vs PRODUCED_BY: both describe the Organization-to-product link from opposite sides. Pick one direction. The publisher's own EntityMap typically uses OFFERS ("Acme OFFERS Widget").

### Custom predicates

Declare in the root `vocabulary` block only if genuinely needed. Must be uppercase, must not conflict with standard names, must be documented at a declared namespace URI.

```json
"vocabulary": {
  "predicates": ["POLLINATES", "ZONES_AS"],
  "namespace": "https://acme.com/entitymap/vocab/v1"
}
```

---

## 10. Forbidden inverted predicate forms

Predicates are directional. These inverted or passive forms are invalid and the validator rejects them. If you need the inverse meaning, swap subject and target and use the standard predicate.

```
ENABLED_BY        -> flip: Tool ENABLES Outcome
MEASURED_BY       -> flip: Metric MEASURES Concept
PRODUCES          -> flip: Product PRODUCED_BY Organization
PRODUCED_FOR      -> flip: Product PRODUCED_BY Organization
DEPENDED_ON_BY    -> flip: Dependent DEPENDS_ON Dependency
REQUIRED_BY       -> flip: Consumer REQUIRES Dependency
IMPROVED_BY       -> flip: Cause IMPROVES Effect
DEGRADED_BY       -> flip: Cause DEGRADES Effect
COVERS_BY         -> flip: Hub COVERS SubTopic
COVERED_BY        -> flip: Hub COVERS SubTopic
DESCRIBES         -> use DESCRIBED_BY in the reverse direction
OFFERED_BY        -> flip: Organization OFFERS Product
```

The only standard predicates that end in `_BY` are AUTHORED_BY, PRODUCED_BY, REGULATED_BY, and DESCRIBED_BY. Any other `_BY` predicate is an invented inverse. Swap subject and target instead.

---

## 11. The sameAs rule

Do NOT add `sameAs` URIs (Wikidata, Wikipedia, or any external knowledge graph) at generation time. Models reliably invent Q-numbers and URLs that look correct but point at the wrong concept or do not exist. Leave `sameAs` out. The user adds them by hand by searching wikidata.org for each entity, strongly recommended for Concept types.

Exception: if the user explicitly asks for a `sameAs` URI for a specific named entity, suggest one and tag it `VERIFY ON WIKIDATA` beside the output so they check it.

---

## 12. Validation rules

The validator at entitymap.org/validate rejects these as errors:

- Missing any required field at root, entity, or chunk level.
- Use of a v0.x legacy type (DefinedTerm, Product, ScholarlyArticle, CreativeWork).
- Chunk `publisher` not exactly matching `publisher.name`.
- Tier 3 predicate without a `confidence` field.
- `status: "deprecated"` or `"merged"` without `replacedBy`.
- MEASURES on a non-Metric source entity.
- AFFILIATED_WITH on a non-Person source entity.
- COVERS on a non-hub source type (not Concept, ProprietaryTerm, or Taxonomy).
- OFFERS on a source outside {Organization, Platform, Service, SoftwareProduct}. Note: the generation prompt states Organization-only, but the predicates page and the live reference implementation permit the broader set. This validator follows the live standard. The company-to-product OFFERS ("Acme OFFERS Acme Platform") is the canonical, safest usage.
- Both directions of PART_OF/INCLUDES between the same pair.
- IMPROVES and DEGRADES, or ENABLES and PREVENTS, or OFFERS and PRODUCED_BY, between the same pair.
- Any forbidden inverted predicate form (§10).
- Chunk text exceeding 600 characters.
- More than 5 chunks per entity.
- `certification.url` present but domain segment does not match `publisher.url` hostname, or not in the form `https://entitymap.org/certified/{domain}/{token}`.

Advisory warnings (not errors): missing `sameAs` on Concept types, RELATES_TO above 20% of relations, `verificationStatus: "third-party-verified"` without a `certification` field, `confidence: "inferred"` without a `context` object, LEADS_TO without `context.condition`.

---

## 13. Certification and verification status

Two trust signals at root level. `verificationStatus` is publisher-declared; `certification` is issued by a third-party registry. The registry is the authority.

verificationStatus values:
- `"self-declared"` — publisher asserts accuracy, no third-party verification. Default for hand-written or fully reviewed files.
- `"generator-draft"` — produced by an automated generator without human review. Consumers apply lower reasoning weight to Tier 3 predicates. Required for any LLM-assisted file not yet reviewed line by line.
- `"third-party-verified"` — must be backed by a valid `certification` field, else treat as self-declared.

The certification registry launches Q3 2026. The `certification` field is fully specified and validator-checked now, but do not fabricate one. Leave it out for generated drafts.

---

## 14. The HTML companion file

`entitymap.html` is generated from `entitymap.json` and MUST NOT be maintained independently. A conforming file MUST:

- Reference `entitymap.json` via `<link rel="alternate" type="application/json">`.
- Embed per-entity JSON-LD in `<script type="application/ld+json">` blocks.
- Render relations as internal hyperlinks where targets exist in the same file.
- Include a `data-publisher` attribute on every chunk blockquote.
- Render the publisher name as visible plain text in each chunk's `<cite>` element. Pattern: *[page title] - published by [publisher name]*.
- Not carry a `noindex` directive.

The visible-text attribution requirement exists because many LLM pipelines strip HTML tags before ingestion, discarding metadata. The cite text is the fallback that survives plain-text ingestion.

```html
<blockquote data-publisher="Acme Corp">
  "Chunk text here."
  <cite><a href="https://acme.com/page">Page title</a> - published by Acme Corp</cite>
</blockquote>
```

---

## 15. Deploy and discovery

1. Serve both files at the domain root, public, no authentication, no subdirectory paths.
2. robots.txt hint:
   ```
   # EntityMap
   EntityMap: https://yourdomain.com/entitymap.json
   ```
3. HTML head link on every page:
   ```html
   <link rel="entitymap" type="application/json" href="https://yourdomain.com/entitymap.json" />
   ```
4. List `entitymap.html` in sitemap.xml with `priority: 0.9` and `changefreq: weekly`.
5. Sitewide footer link to `entitymap.html` (not the JSON). This is the most reliable discovery mechanism; every crawler that follows HTML links finds it.

---

## 16. Sharding (large sites)

For files over 200 entities, shard by size, not by entity type. The root `entitymap.json` becomes a manifest listing shards with entity counts and `lastModified` timestamps. Each shard carries a `shardOf` field pointing back to the manifest. Consumers load all shards; the split carries no semantic meaning.

```
/entitymap.json              <- manifest
/entitymap/part-001.json
/entitymap/part-002.json
```
