#!/usr/bin/env python3
"""
Generate entitymap.html from a conforming entitymap.json.

Usage:
    python3 generate_html.py path/to/entitymap.json path/to/entitymap.html

Produces a crawler- and human-readable companion file per EntityMap v1.0 section 14:
- references entitymap.json via <link rel="alternate" type="application/json">
- embeds per-entity JSON-LD in <script type="application/ld+json"> blocks
- renders relations as internal hyperlinks where the target exists in the file
- carries a data-publisher attribute on every chunk blockquote
- renders the publisher name as visible plain text in each chunk's <cite>
- carries no noindex directive

The HTML is generated from the JSON and must never be edited by hand.
"""

import html
import json
import sys


def esc(value):
    return html.escape(str(value), quote=True)


def main(json_path, html_path):
    with open(json_path, "r", encoding="utf-8") as fh:
        doc = json.load(fh)

    publisher = doc.get("publisher", {})
    pub_name = publisher.get("name", "")
    pub_url = publisher.get("url", "")
    generated = doc.get("generated", "")
    entities = doc.get("entities", [])
    id_to_name = {e.get("entityId"): e.get("name") for e in entities if e.get("entityId")}

    json_href = "/entitymap.json"

    parts = []
    parts.append("<!DOCTYPE html>")
    parts.append('<html lang="en">')
    parts.append("<head>")
    parts.append('<meta charset="utf-8">')
    parts.append('<meta name="viewport" content="width=device-width, initial-scale=1">')
    parts.append('<meta name="robots" content="index, follow">')
    parts.append(f"<title>EntityMap - {esc(pub_name)}</title>")
    parts.append(
        f'<meta name="description" content="Structured, entity-first knowledge index for {esc(pub_name)}, '
        f'published for AI agents, LLMs, and RAG pipelines per the EntityMap v1.0 standard.">'
    )
    parts.append(f'<link rel="alternate" type="application/json" href="{esc(json_href)}">')
    parts.append('<style>')
    parts.append(
        "body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;"
        "max-width:880px;margin:0 auto;padding:2rem 1.25rem;line-height:1.55;color:#1a1a1a}"
        "header{border-bottom:1px solid #e2e2e2;padding-bottom:1rem;margin-bottom:2rem}"
        "h1{font-size:1.6rem;margin:0 0 .25rem}"
        ".meta{color:#666;font-size:.85rem}"
        "section.entity{border:1px solid #e6e6e6;border-radius:8px;padding:1.25rem 1.25rem .5rem;margin:0 0 1.5rem}"
        "h2{font-size:1.2rem;margin:.1rem 0 .25rem}"
        ".type{display:inline-block;font-size:.7rem;letter-spacing:.04em;text-transform:uppercase;"
        "background:#f0f0f0;border-radius:4px;padding:.15rem .5rem;color:#444;margin-left:.4rem;vertical-align:middle}"
        ".desc{margin:.5rem 0 1rem}"
        ".rels{font-size:.9rem;margin:.5rem 0 1rem;padding:0;list-style:none}"
        ".rels li{margin:.2rem 0}"
        ".pred{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.8rem;"
        "background:#eef6f0;color:#0a7a45;padding:.05rem .35rem;border-radius:3px}"
        "blockquote{margin:.6rem 0;padding:.6rem .9rem;border-left:3px solid #20CE88;background:#fafafa}"
        "blockquote cite{display:block;margin-top:.4rem;font-size:.8rem;color:#555;font-style:normal}"
        "a{color:#0a7a45}"
        "footer{border-top:1px solid #e2e2e2;margin-top:2rem;padding-top:1rem;font-size:.85rem;color:#666}"
    )
    parts.append('</style>')
    parts.append("</head>")
    parts.append("<body>")

    parts.append("<header>")
    parts.append(f"<h1>EntityMap: {esc(pub_name)}</h1>")
    parts.append(
        f'<p class="meta">A structured, entity-first index of what '
        f'<a href="{esc(pub_url)}">{esc(pub_name)}</a> knows, published for AI systems. '
        f"Generated {esc(generated)}. Machine-readable source: "
        f'<a href="{esc(json_href)}">entitymap.json</a>.</p>'
    )
    parts.append("</header>")

    for ent in entities:
        eid = ent.get("entityId", "")
        name = ent.get("name", "")
        etype = ent.get("@type", "")
        desc = ent.get("description", "")
        alt = ent.get("alternateName")
        canon = ent.get("canonicalLabel")
        same_as = ent.get("sameAs")

        parts.append(f'<section class="entity" id="{esc(eid)}">')
        parts.append(f'<h2>{esc(name)}<span class="type">{esc(etype)}</span></h2>')
        sub = []
        if alt:
            sub.append(f"also: {esc(alt)}")
        if canon:
            sub.append(f"general label: {esc(canon)}")
        if sub:
            parts.append(f'<p class="meta">{" &middot; ".join(sub)}</p>')
        parts.append(f'<p class="desc">{esc(desc)}</p>')

        # relations as internal hyperlinks where target exists
        rels = ent.get("relations") or []
        if rels:
            parts.append('<ul class="rels">')
            for rel in rels:
                pred = rel.get("predicate", "")
                tid = rel.get("targetId")
                tname = rel.get("targetName", id_to_name.get(tid, tid or ""))
                conf = rel.get("confidence")
                conf_txt = f' <span class="meta">({esc(conf)})</span>' if conf else ""
                if tid and tid in id_to_name:
                    target_html = f'<a href="#{esc(tid)}">{esc(tname)}</a>'
                elif rel.get("targetUri"):
                    target_html = f'<a href="{esc(rel["targetUri"])}">{esc(tname)}</a>'
                else:
                    target_html = esc(tname)
                parts.append(
                    f'<li><span class="pred">{esc(pred)}</span> &rarr; {target_html}{conf_txt}</li>'
                )
            parts.append("</ul>")

        # chunks as attributed blockquotes
        for ch in ent.get("hasChunks") or []:
            text = ch.get("text", "")
            src = ch.get("sourceUrl", "")
            ptitle = ch.get("pageTitle", "")
            cpub = ch.get("publisher", pub_name)
            parts.append(f'<blockquote data-publisher="{esc(cpub)}">')
            parts.append(f"{esc(text)}")
            parts.append(
                f'<cite><a href="{esc(src)}">{esc(ptitle)}</a> - published by {esc(cpub)}</cite>'
            )
            parts.append("</blockquote>")

        # per-entity JSON-LD
        first_chunk = (ent.get("hasChunks") or [{}])[0]
        ld = {
            "@context": "https://schema.org",
            "@type": "Thing",
            "additionalType": f"https://entitymap.org/spec/v1.0#{etype}",
            "name": name,
            "description": desc,
            "identifier": eid,
        }
        if alt:
            ld["alternateName"] = alt
        if same_as:
            ld["sameAs"] = same_as
        if first_chunk.get("sourceUrl"):
            ld["url"] = first_chunk["sourceUrl"]
        citations = [c.get("sourceUrl") for c in (ent.get("hasChunks") or []) if c.get("sourceUrl")]
        if citations:
            ld["citation"] = citations
        parts.append('<script type="application/ld+json">')
        parts.append(json.dumps(ld, ensure_ascii=False, indent=2))
        parts.append("</script>")

        parts.append("</section>")

    parts.append("<footer>")
    parts.append(
        f"Published by {esc(pub_name)} under the EntityMap v1.0 open standard. "
        f'This page is generated from <a href="{esc(json_href)}">entitymap.json</a> and must not be edited by hand.'
    )
    parts.append("</footer>")
    parts.append("</body>")
    parts.append("</html>")

    out = "\n".join(parts)
    with open(html_path, "w", encoding="utf-8") as fh:
        fh.write(out)
    print(f"Wrote {html_path} ({len(entities)} entities, {len(out)} bytes)")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 generate_html.py path/to/entitymap.json path/to/entitymap.html")
        sys.exit(2)
    main(sys.argv[1], sys.argv[2])
