#!/usr/bin/env python3
"""
EntityMap v1.0 conformance validator.

Usage:
    python3 validate.py path/to/entitymap.json

Checks every error condition in the EntityMap v1.0 spec plus advisory warnings.
Exit code 0 if no errors (warnings allowed), 1 if any error, 2 on load failure.
"""

import json
import sys
from collections import Counter

SCHEMA_URL = "https://entitymap.org/spec/v1.0"

CORE_TYPES = {
    # Tier 1 Knowledge
    "Concept", "ProprietaryTerm", "Methodology", "Metric", "Taxonomy",
    # Tier 2 Actor
    "Person", "Organization", "SoftwareProduct", "PhysicalProduct",
    "Service", "Platform", "Place",
    # Tier 3 Temporal
    "Event", "Standard", "Regulation",
    # Tier 4 Content (reference-prompt addition)
    "Guide",
}
LEGACY_TYPES = {"DefinedTerm", "Product", "ScholarlyArticle", "CreativeWork"}

TIER1 = {"INSTANCE_OF", "PART_OF", "INCLUDES", "DEPENDS_ON", "REQUIRES",
         "MEASURES", "PRODUCED_BY", "REGULATED_BY", "AUTHORED_BY",
         "AFFILIATED_WITH", "COVERS"}
TIER2 = {"RELATES_TO", "PRECEDES", "ENABLES", "PREVENTS", "CONFLICTS_WITH",
         "DESCRIBED_BY", "OFFERS"}
TIER3 = {"IMPROVES", "DEGRADES", "LEADS_TO", "SUITED_FOR", "TARGETS", "ACHIEVES"}
STANDARD_PREDICATES = TIER1 | TIER2 | TIER3

FORBIDDEN_INVERTED = {
    "ENABLED_BY", "MEASURED_BY", "PRODUCES", "PRODUCED_FOR", "DEPENDED_ON_BY",
    "REQUIRED_BY", "IMPROVED_BY", "DEGRADED_BY", "COVERS_BY", "COVERED_BY",
    "DESCRIBES", "OFFERED_BY", "AFFILIATED_WITH_BY", "INCLUDED_BY",
    "PART_OF_BY", "INSTANCE_OF_BY",
}

# Inverse pairs: declaring both predicates between the same unordered entity pair is an error.
INVERSE_PAIRS = [
    ("PART_OF", "INCLUDES"),
    ("IMPROVES", "DEGRADES"),
    ("ENABLES", "PREVENTS"),
    ("OFFERS", "PRODUCED_BY"),
]

# The predicates page allows OFFERS from Organization, Platform, Service, or
# SoftwareProduct, and the live reference implementation uses SoftwareProduct.
# The generation prompt is stricter (Organization only); we follow the live
# standard to avoid false failures on conforming files.
OFFERS_SOURCE_TYPES = {"Organization", "Platform", "Service", "SoftwareProduct"}
OFFERS_TARGET_TYPES = {"SoftwareProduct", "Service", "Platform", "PhysicalProduct"}
COVERS_SOURCE_TYPES = {"Concept", "ProprietaryTerm", "Taxonomy"}

errors = []
warnings = []


def err(msg):
    errors.append(msg)


def warn(msg):
    warnings.append(msg)


def main(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            doc = json.load(fh)
    except FileNotFoundError:
        print(f"LOAD ERROR: file not found: {path}")
        sys.exit(2)
    except json.JSONDecodeError as e:
        print(f"LOAD ERROR: invalid JSON: {e}")
        sys.exit(2)

    # ---- Root ----
    for field in ("version", "schema", "publisher", "generated", "entities"):
        if field not in doc:
            err(f"root: missing required field '{field}'")

    if doc.get("version") != "1.0":
        err(f"root.version must be '1.0', got {doc.get('version')!r}")
    if doc.get("schema") != SCHEMA_URL:
        err(f"root.schema must be '{SCHEMA_URL}', got {doc.get('schema')!r}")

    publisher = doc.get("publisher") or {}
    pub_name = publisher.get("name")
    if not pub_name:
        err("root.publisher.name is required")
    if not publisher.get("url"):
        err("root.publisher.url is required")

    # custom vocabulary
    declared_predicates = set()
    vocab = doc.get("vocabulary") or {}
    for p in (vocab.get("predicates") or []):
        declared_predicates.add(p)

    # verification / certification cross-checks
    vstatus = doc.get("verificationStatus", "self-declared")
    cert = doc.get("certification")
    if vstatus == "third-party-verified" and not cert:
        warn("verificationStatus is 'third-party-verified' but no certification field is present")
    if cert and isinstance(cert, dict):
        url = cert.get("url", "")
        if not url.startswith("https://entitymap.org/certified/"):
            err("certification.url must be of the form https://entitymap.org/certified/{domain}/{token}")
        else:
            try:
                cert_domain = url.split("/certified/")[1].split("/")[0]
                pub_host = (publisher.get("url", "").split("://")[-1].split("/")[0])
                if cert_domain != pub_host:
                    err(f"certification.url domain '{cert_domain}' does not match publisher.url host '{pub_host}'")
            except IndexError:
                err("certification.url is malformed")

    entities = doc.get("entities") or []
    if not isinstance(entities, list) or len(entities) < 1:
        err("root.entities must be a non-empty array")
        _report(path)

    # ---- Index entities ----
    id_to_type = {}
    id_counts = Counter()
    chunk_ids = Counter()
    for ent in entities:
        eid = ent.get("entityId")
        if eid:
            id_counts[eid] += 1
            id_to_type[eid] = ent.get("@type")

    for eid, c in id_counts.items():
        if c > 1:
            err(f"duplicate entityId '{eid}' ({c} times)")

    # collected relation predicates per unordered pair, for inverse-pair detection
    pair_predicates = {}
    total_relations = 0
    relates_to_count = 0

    # ---- Entities ----
    for i, ent in enumerate(entities):
        loc = f"entity[{i}]"
        eid = ent.get("entityId")
        etype = ent.get("@type")
        if eid:
            loc = f"entity '{eid}'"

        for field in ("entityId", "@type", "name", "description", "hasChunks"):
            if field not in ent or ent.get(field) in (None, ""):
                err(f"{loc}: missing required field '{field}'")

        # type checks
        if etype in LEGACY_TYPES:
            err(f"{loc}: uses v0.x legacy type '{etype}' (rejected by validator)")
        elif etype and etype not in CORE_TYPES and ":" not in str(etype):
            err(f"{loc}: '@type' '{etype}' is not a core type and is not namespaced (e.g. ns:Custom)")

        # status / replacedBy
        status = ent.get("status", "active")
        if status in ("deprecated", "merged") and not ent.get("replacedBy"):
            err(f"{loc}: status '{status}' requires 'replacedBy'")

        # sameAs advisory for Concept
        if etype == "Concept" and not ent.get("sameAs"):
            warn(f"{loc}: Concept type without 'sameAs' (recommended; add by hand from wikidata.org)")

        # chunks
        chunks = ent.get("hasChunks") or []
        if isinstance(chunks, list):
            if len(chunks) < 1:
                err(f"{loc}: must have at least 1 chunk")
            if len(chunks) > 5:
                err(f"{loc}: has {len(chunks)} chunks, max 5 per entity")
            for j, ch in enumerate(chunks):
                cloc = f"{loc} chunk[{j}]"
                cid = ch.get("chunkId")
                if cid:
                    chunk_ids[cid] += 1
                    cloc = f"{loc} chunk '{cid}'"
                for field in ("chunkId", "text", "sourceUrl", "pageTitle", "publisher"):
                    if not ch.get(field):
                        err(f"{cloc}: missing required field '{field}'")
                text = ch.get("text", "")
                if isinstance(text, str) and len(text) > 600:
                    err(f"{cloc}: text is {len(text)} chars, max 600")
                cpub = ch.get("publisher")
                if cpub is not None and pub_name is not None and cpub != pub_name:
                    err(f"{cloc}: publisher {cpub!r} does not exactly match root publisher.name {pub_name!r}")

        # relations
        rels = ent.get("relations") or []
        for k, rel in enumerate(rels):
            rloc = f"{loc} relation[{k}]"
            total_relations += 1
            pred = rel.get("predicate")
            if not pred:
                err(f"{rloc}: missing required field 'predicate'")
                continue
            if not rel.get("targetName"):
                err(f"{rloc}: missing required field 'targetName'")

            # predicate validity
            if pred in FORBIDDEN_INVERTED:
                err(f"{rloc}: forbidden inverted predicate '{pred}' (flip subject/target and use the standard predicate)")
            elif pred not in STANDARD_PREDICATES and pred not in declared_predicates:
                err(f"{rloc}: predicate '{pred}' is not a standard predicate or declared custom vocabulary")

            # Tier 3 confidence
            if pred in TIER3 and "confidence" not in rel:
                err(f"{rloc}: Tier 3 predicate '{pred}' requires a 'confidence' field")
            if rel.get("confidence") == "inferred" and not rel.get("context"):
                warn(f"{rloc}: confidence 'inferred' without a 'context' object (consumers discount heavily)")
            if pred == "LEADS_TO" and not (rel.get("context") or {}).get("condition"):
                warn(f"{rloc}: LEADS_TO without context.condition (recommended)")

            # RELATES_TO budget
            if pred == "RELATES_TO":
                relates_to_count += 1

            # type-constrained source predicates
            if pred == "MEASURES" and etype != "Metric":
                err(f"{rloc}: MEASURES requires source @type 'Metric', source is '{etype}'")
            if pred == "AFFILIATED_WITH" and etype != "Person":
                err(f"{rloc}: AFFILIATED_WITH requires source @type 'Person', source is '{etype}'")
            if pred == "COVERS" and etype not in COVERS_SOURCE_TYPES:
                err(f"{rloc}: COVERS requires source type in {sorted(COVERS_SOURCE_TYPES)}, source is '{etype}'")
            if pred == "OFFERS":
                if etype not in OFFERS_SOURCE_TYPES:
                    err(f"{rloc}: OFFERS requires source type in {sorted(OFFERS_SOURCE_TYPES)}, source is '{etype}'")
                tid = rel.get("targetId")
                ttype = id_to_type.get(tid) if tid else None
                if tid and tid in id_to_type and ttype not in OFFERS_TARGET_TYPES:
                    warn(f"{rloc}: OFFERS target '{tid}' is '{ttype}', not a product type {sorted(OFFERS_TARGET_TYPES)} (allowed by live reference, flagged for review)")

            # internal targetId resolution
            tid = rel.get("targetId")
            if tid and tid not in id_to_type:
                err(f"{rloc}: targetId '{tid}' does not resolve to any entityId in this file")

            # record predicate for inverse-pair detection
            tkey = rel.get("targetId") or rel.get("targetName")
            if eid and tkey:
                pair = frozenset((eid, tkey))
                pair_predicates.setdefault(pair, set()).add(pred)

    # duplicate chunk ids
    for cid, c in chunk_ids.items():
        if c > 1:
            err(f"duplicate chunkId '{cid}' ({c} times)")

    # inverse-pair conflicts
    for pair, preds in pair_predicates.items():
        for a, b in INVERSE_PAIRS:
            if a in preds and b in preds:
                names = " / ".join(sorted(pair))
                err(f"both '{a}' and '{b}' declared between the same entity pair ({names})")

    # RELATES_TO budget warning
    if total_relations > 0 and relates_to_count / total_relations > 0.20:
        pct = round(100 * relates_to_count / total_relations)
        warn(f"RELATES_TO is {pct}% of relations (> 20%); replace the weakest with precise predicates")

    _report(path)


def _report(path):
    print(f"EntityMap validation: {path}")
    print("-" * 60)
    if errors:
        print(f"ERRORS ({len(errors)}):")
        for e in errors:
            print(f"  [ERROR] {e}")
    else:
        print("ERRORS: none")
    if warnings:
        print(f"\nWARNINGS ({len(warnings)}):")
        for w in warnings:
            print(f"  [warn]  {w}")
    else:
        print("\nWARNINGS: none")
    print("-" * 60)
    if errors:
        print("RESULT: FAIL")
        sys.exit(1)
    print("RESULT: PASS")
    sys.exit(0)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 validate.py path/to/entitymap.json")
        sys.exit(2)
    main(sys.argv[1])
